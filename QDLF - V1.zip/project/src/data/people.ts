import type { Person, Category } from '@/types';

/**
 * People catalog. Each person has a name, category, profession, and image URL.
 * Images use Wikipedia/Wikimedia Commons URLs where possible for licensing clarity.
 * Profession is a single primary occupation — no compound labels.
 */

const people: Record<string, Person> = {
  // === POLÍTICOS ===
  trump: { name: 'Donald Trump', category: 'politicos', profession: 'Político', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/5/56/Donald_Trump_official_portrait.jpg' },
  obama: { name: 'Barack Obama', category: 'politicos', profession: 'Político', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/8/8d/President_Barack_Obama.jpg' },
  kennedy: { name: 'John F. Kennedy', category: 'politicos', profession: 'Político', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/3/3f/John_F._Kennedy%2C_White_House_color_photo_portrait.jpg' },
  roosevelt: { name: 'Franklin D. Roosevelt', category: 'politicos', profession: 'Político', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/5/52/FDR_1944_Portrait.jpg' },
  lincoln: { name: 'Abraham Lincoln', category: 'politicos', profession: 'Político', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/4/49/Abraham_Lincoln_seated%2C_1861.jpg' },
  washington: { name: 'George Washington', category: 'politicos', profession: 'Político', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/b/b6/Gilbert_Stuart_Williamstown_Portrait_of_George_Washington.jpg' },
  churchill: { name: 'Winston Churchill', category: 'politicos', profession: 'Político', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/2/2e/Sir_Winston_Churchill_-_19086236948.jpg' },
  mandela: { name: 'Nelson Mandela', category: 'politicos', profession: 'Político', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/0/02/Nelson_Mandela_1994.jpg' },
  gandhi: { name: 'Mahatma Gandhi', category: 'politicos', profession: 'Activista', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/d/d1/Portrait_Gandhi.jpg' },
  king: { name: 'Martin Luther King Jr.', category: 'politicos', profession: 'Activista', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/0/07/Martin_Luther_King_Jr_NYWTS.jpg' },

  // === CIENTÍFICOS ===
  einstein: { name: 'Albert Einstein', category: 'cientificos', profession: 'Físico', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/d/d3/Albert_Einstein_Head.jpg' },
  tesla: { name: 'Nikola Tesla', category: 'cientificos', profession: 'Inventor', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/7/79/Tesla_circa_1890.jpeg' },
  newton: { name: 'Isaac Newton', category: 'cientificos', profession: 'Físico', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/3/39/GodfreyKneller-IsaacNewton-1689.jpg' },
  curie: { name: 'Marie Curie', category: 'cientificos', profession: 'Física', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/7/7e/Marie_Curie_c._1920s.jpg' },
  darwin: { name: 'Charles Darwin', category: 'cientificos', profession: 'Biólogo', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/2/2c/Charles_Darwin_by_Julia_Margaret_Cameron_3.jpg' },
  hawking: { name: 'Stephen Hawking', category: 'cientificos', profession: 'Físico', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/e/eb/Stephen_Hawking.StarChild.jpg' },
  galileo: { name: 'Galileo Galilei', category: 'cientificos', profession: 'Astrónomo', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/d/d4/Justus_Sustermans_-_Portrait_of_Galileo_Galilei_-_Google_Art_Project.jpg' },
  feynman: { name: 'Richard Feynman', category: 'cientificos', profession: 'Físico', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/4/47/Richard_Feynman_circa_1985.jpg' },

  // === FILÓSOFOS Y ESCRITORES ===
  nietzsche: { name: 'Friedrich Nietzsche', category: 'filosofos', profession: 'Filósofo', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/9/98/Nietzsche187a.jpg' },
  socrates: { name: 'Sócrates', category: 'filosofos', profession: 'Filósofo', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/a/a9/Socrates_Louvre.jpg' },
  plato: { name: 'Platón', category: 'filosofos', profession: 'Filósofo', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/4/4a/Plato_Silanion_Musei_Capitolini_MC1377.jpg' },
  aristotle: { name: 'Aristóteles', category: 'filosofos', profession: 'Filósofo', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/a/ae/Aristotle_Altemps_Inv8575.jpg' },
  twain: { name: 'Mark Twain', category: 'filosofos', profession: 'Escritor', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/0/05/Mark_Twain_by_Abdullah_Frères%2C_1867.jpg' },
  wilde: { name: 'Oscar Wilde', category: 'filosofos', profession: 'Escritor', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/d/d5/Oscar_Wilde_1882.jpg' },
  cervantes: { name: 'Miguel de Cervantes', category: 'filosofos', profession: 'Escritor', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/8/83/Cervantes_J%C3%A1uregui.jpg' },
  shakespeare: { name: 'William Shakespeare', category: 'filosofos', profession: 'Dramaturgo', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/a/a2/Shakespeare.jpg' },
  camus: { name: 'Albert Camus', category: 'filosofos', profession: 'Filósofo', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/0/08/Albert_Camus_1957.jpg' },
  descartes: { name: 'René Descartes', category: 'filosofos', profession: 'Filósofo', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/c/cd/Frans_Hals_-_Portret_van_Ren%C3%A9_Descartes.jpg' },
  voltaire: { name: 'Voltaire', category: 'filosofos', profession: 'Filósofo', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/4/49/Nicolas_de_Largilli%C3%A8re%2C_Portrait_de_Voltaire%2C_dit_%C3%A9galement_Portrait_aux_lices.jpg' },

  // === FAMOSOS ===
  jackson: { name: 'Michael Jackson', category: 'famosos', profession: 'Cantante', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/3/31/Michael_Jackson_in_1988.jpg' },
  presley: { name: 'Elvis Presley', category: 'famosos', profession: 'Cantante', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/9/95/Elvis_Presley_1957.jpg' },
  jobs: { name: 'Steve Jobs', category: 'famosos', profession: 'Empresario', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/f/f5/Steve_Jobs_Headshot.jpg' },
  ali: { name: 'Muhammad Ali', category: 'famosos', profession: 'Boxeador', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/8/89/Muhammad_Ali_NYWTS.jpg' },
  jordan: { name: 'Michael Jordan', category: 'famosos', profession: 'Baloncestista', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/b/b9/Michael_Jordan_in_2014.jpg' },
  marley: { name: 'Bob Marley', category: 'famosos', profession: 'Cantante', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/7/7d/Bob-Marley-in-Concert_Zurich_05-30-80.jpg' },

  // === CREADORES DE CONTENIDO / EMPRESARIOS ===
  elon: { name: 'Elon Musk', category: 'creadores', profession: 'Empresario', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/3/34/Elon_Musk_Royal_Society_%28crop2%29.jpg' },

  // === STREAMERS ===
  rubius: { name: 'El Rubius', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  auron: { name: 'AuronPlay', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  ibai: { name: 'Ibai', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  xokas: { name: 'ElXokas', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  bananirou: { name: 'Bananirou', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  spreen: { name: 'Spreen', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  mrbeast: { name: 'MrBeast', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  stable_ronaldo: { name: 'Stable Ronaldo', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  kai_cenat: { name: 'Kai Cenat', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  speed: { name: 'Speed', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  coscu: { name: 'Coscu', category: 'streamers', profession: 'Streamer', imageUrl: '' },

  // === STREAMERS NUEVOS ===
  robleis: { name: 'Robleis', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  davoxeneixe: { name: 'DavoXeneixe', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  la_cobra: { name: 'La Cobra', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  el_mariana: { name: 'ElMariana', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  westcol: { name: 'WestCOL', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  illojuan: { name: 'IlloJuan', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  pokimane: { name: 'Pokimane', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  jynxzi: { name: 'Jynxzi', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  xqc: { name: 'xQc', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  juansguarnizo: { name: 'Juansguarnizo', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  momo: { name: 'Momo', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  ninja: { name: 'Ninja', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  tfue: { name: 'Tfue', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  zias_blou: { name: 'Zias y B.Lou', category: 'streamers', profession: 'Streamers', imageUrl: '' },
  thegrefg: { name: 'TheGrefg', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  alonso: { name: 'Alonso (el down)', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  lacy: { name: 'Lacy', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  jasontheween: { name: 'Jasontheween', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  agusneta: { name: 'Agusneta', category: 'streamers', profession: 'Streamer', imageUrl: '' },

  // === CIENTÍFICOS ADICIONALES ===
  turing: { name: 'Alan Turing', category: 'cientificos', profession: 'Matemático', imageUrl: '' },
  edison: { name: 'Thomas Edison', category: 'cientificos', profession: 'Inventor', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/9/97/Thomas_Edison2-crop.jpg' },
  terence_tao: { name: 'Terence Tao', category: 'cientificos', profession: 'Matemático', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/7/7e/Terence_Tao_2006.jpg' },
  pitagoras: { name: 'Pitágoras', category: 'cientificos', profession: 'Matemático', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/1/1a/Kapitolinischer_Pythagoras_adjusted.jpg' },
  euclides: { name: 'Euclides', category: 'cientificos', profession: 'Matemático', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/9/91/Euclid Statue.jpg' },
  davinci: { name: 'Leonardo da Vinci', category: 'cientificos', profession: 'Inventor', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/4/4f/Leonardo_da_Vinci_-_presumed_self-portrait_-_WGA12798.jpg' },

  // === FILÓSOFOS Y PENSADORES ADICIONALES ===
  marco_aurelio: { name: 'Marco Aurelio', category: 'filosofos', profession: 'Filósofo', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/2/2f/Marcus_Aurelius_Glyptothek_Munich.jpg' },

  // === FIGURAS HISTÓRICAS Y ESCRITORES ===
  bobby_fischer: { name: 'Bobby Fischer', category: 'famosos', profession: 'Ajedrecista', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/1/1a/Bobby_Fischer_1960.jpg' },
  julio_cesar: { name: 'Julio César', category: 'politicos', profession: 'Militar', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/9/9d/Retrato_de_Julio_C%C3%A9sar_%2826723493101%29.jpg' },
  alejandro_magno: { name: 'Alejandro Magno', category: 'politicos', profession: 'Conquistador', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/1/1a/AlexanderTheGreat_British_Museum.jpg' },
  quevedo: { name: 'Francisco de Quevedo', category: 'filosofos', profession: 'Escritor', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/1/1e/Francisco_de_Quevedo_by_Francisco_Pacheco.jpg' },

  // === STREAMERS ADICIONALES ===
  kun_aguero: { name: 'Kun Agüero', category: 'streamers', profession: 'Streamer', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/2/24/Sergio_Aguero_2018.jpg' },
  onhepixle: { name: 'onhepixle', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  emiru: { name: 'Emiru', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  rakai: { name: 'Rakai', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  marlon: { name: 'Marlon', category: 'streamers', profession: 'Streamer', imageUrl: '' },
  tomasmazza: { name: 'TomasMazza', category: 'streamers', profession: 'Streamer', imageUrl: '' },
};

export function getPerson(key: string): Person {
  return people[key];
}

export function getRandomDecoy(authorKey: string): string {
  const allKeys = Object.keys(people).filter((k) => k !== authorKey);
  return allKeys[Math.floor(Math.random() * allKeys.length)];
}

export const categoryLabels: Record<Category, string> = {
  streamers: 'Streamers',
  creadores: 'Creadores de contenido',
  famosos: 'Famosos',
  politicos: 'Políticos',
  cientificos: 'Científicos',
  filosofos: 'Filósofos y escritores',
  internet: 'Cultura de Internet',
};

export { people };
