import { useState, useRef } from 'react';
import type { GameState, Screen, Quote } from '@/types';
import { getInitialGameState, setBestScore } from '@/lib/game';
import { StartScreen } from '@/screens/StartScreen';
import { GameScreen } from '@/screens/GameScreen';
import { ResultScreen } from '@/screens/ResultScreen';
import { LeaderboardScreen } from '@/screens/LeaderboardScreen';

function App() {
  const [screen, setScreen] = useState<Screen>('start');
  const [gameState, setGameState] = useState<GameState>(getInitialGameState);
  const [lastQuote, setLastQuote] = useState<Quote | null>(null);
  const previousScreen = useRef<Screen>('start');
  const gameStarted = useRef(false);

  const handleStart = () => {
    setGameState(getInitialGameState());
    setLastQuote(null);
    gameStarted.current = true;
    setScreen('game');
  };

  const handleGameOver = (finalState: GameState, quote: Quote) => {
    setBestScore(finalState.score);
    setGameState(finalState);
    setLastQuote(quote);
    setScreen('result');
  };

  const handlePlayAgain = () => {
    setGameState(getInitialGameState());
    setLastQuote(null);
    setScreen('game');
  };

  const handleMenu = () => {
    setScreen('start');
  };

  const handleShowLeaderboard = () => {
    previousScreen.current = screen;
    setScreen('leaderboard');
  };

  const handleBackFromLeaderboard = () => {
    const prev = previousScreen.current;
    if (prev === 'game' && gameStarted.current) {
      setScreen('game');
    } else if (prev === 'result' && lastQuote) {
      setScreen('result');
    } else {
      setScreen('start');
    }
  };

  return (
    <>
      {/* Start screen */}
      <div className={screen === 'start' ? 'block' : 'hidden'}>
        <StartScreen onStart={handleStart} onShowLeaderboard={handleShowLeaderboard} />
      </div>

      {/* Game screen — kept mounted to preserve round state during leaderboard visits */}
      <div className={screen === 'game' ? 'block' : 'hidden'}>
        <GameScreen
          state={gameState}
          onUpdateState={setGameState}
          onGameOver={handleGameOver}
          onShowLeaderboard={handleShowLeaderboard}
          onMenu={handleMenu}
        />
      </div>

      {/* Result screen */}
      {lastQuote && (
        <div className={screen === 'result' ? 'block' : 'hidden'}>
          <ResultScreen
            state={gameState}
            lastQuote={lastQuote}
            onPlayAgain={handlePlayAgain}
            onMenu={handleMenu}
            onShowLeaderboard={handleShowLeaderboard}
          />
        </div>
      )}

      {/* Leaderboard screen — rendered on top */}
      {screen === 'leaderboard' && (
        <LeaderboardScreen onBack={handleBackFromLeaderboard} />
      )}
    </>
  );
}

export default App;
